<div class="mark">
    <?php if(session('msg')): ?>
        <p style="color:red"><?php echo e(session('msg')); ?></p>
    <?php endif; ?>
    <?php if(is_object($errors)): ?>
        <?php foreach($errors->all() as $error): ?>
            <p><?php echo e($error); ?></p>
        <?php endforeach; ?>
    <?php else: ?>
        <p><?php echo e($errors); ?></p>
    <?php endif; ?>
</div>