<?php $__env->startSection('content'); ?>
    <!--内容区域-->
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h4>考试记录</h4>
                <ul class="list-group">
                    <?php foreach($papers as $paper): ?>
                        <li class="list-group-item" onclick="javascript:window.location.href='<?php echo e(url('paper')); ?>' + '/' + '<?php echo e($paper->paper_id); ?>'">
                            试卷编号: <a href='<?php echo e(url('paper') . '/' . $paper->paper_id); ?>'  ><?php echo e($paper->paper_id); ?></a>&nbsp;
                            成绩:<span style="color:red"><?php echo e($paper->total_score); ?></span> 分&nbsp;&nbsp;&nbsp;&nbsp;
                            用时: <?php echo e(gmstrftime('%H:%M:%S',intval($paper->updated_at) - intval($paper->created_at))); ?>

                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-xs-12">
                <nav>
                    <ul class="pagination">
                        <?php echo e($papers->links()); ?>

                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!--内容区域 end -->

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>