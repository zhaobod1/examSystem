<?php

namespace App\Http\Controllers\Admin;

use App\Http\Model\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;

class UserController extends CommonController
{
    //

    public function index(Request $request)
    {
        $category = $request->get('category');
        if (isset($category)) {

            switch ($category) {
                case 0:
                    $datas = User::whereRaw('user_id>? and user_check=?', [1, 0])->orderBy('updated_at', 'DESC')
                        ->paginate(10);
                    break;
                case 1:
                    $datas = User::whereRaw('user_id>? and user_check=?', [1, 1])->orderBy('updated_at', 'DESC')
                        ->paginate(10);
                    break;
                default:
                    $datas = User::whereRaw('user_id>?', [1])->orderBy('updated_at', 'DESC')->paginate(10);
                    break;

            }

        } else {
            $category = 2;
            $datas = User::whereRaw('user_id>?', [1])->orderBy('updated_at', 'DESC')->paginate(10);
        }

        //全部会员
        $sumUser = User::where('user_id', '>', 1)->count();
        //已审核会员
        $sumCheckedUser = User::whereRaw('user_id>? and user_check=?', [1, 1])->count();

        return view('admin.users.index', compact('datas', 'sumUser', 'sumCheckedUser', 'category'));
    }


    public function create()
    {

        return view('admin.users.add');
    }

    public function store()
    {

        $input = Input::except(['_token']);
        $input['created_at'] = time();
        $input['updated_at'] = time();


        $rules = [
            'user_name' => 'required',
            'user_phone' => 'required|numeric',
            'user_password' => 'required|between:2,60|confirmed',
            'user_check' => 'required|boolean',
        ];
        $message = [
            'user_name.required' => '用户名不能为空!',
            'user_phone.required' => '题目内容不能为空!',
            'user_password.required' => '密码不能为空!',
            'user_check.required' => '审核状态不能为空!',
            'user_check.boolean' => '审核状态有误!',
            'user_password.confirmed' => '确认密码与密码不一致!',
            'user_phone.numeric' => '手机号必须是数字!',
        ];

        $validator = Validator::make($input, $rules, $message);

        if ($validator->passes()) {
            $count = User::where('user_name', $input['user_name'])->count();

            if ($count) {
                return redirect()->back()->with('errors', '用户名已经存在, 请换一个用户名试试。');

            }

            unset($input['user_password_confirmation']);

            $input['user_password'] = Crypt::encrypt($input['user_password']);
            $res = User::create($input);
            if ($res) {
                return redirect('admin/users')->with('success', '添加用户成功');
            } else {
                return redirect()->back()->with('errors', '添加用户失败,存入数据库过程中失败!稍后再试');
            }
        } else {
            return redirect()->back()->withErrors($validator);
        }


    }

    public function edit($user_id)
    {
        if (intval($user_id) == 1) {
            return redirect('admin/users');
        }

        $user = User::find($user_id);
        return view('admin.users.edit', compact('user'));
    }

    //put.admin/users/{user_id}    更新文章
    public function update($user_id)
    {
        if (intval($user_id) == 1) {
            return redirect('admin/users');
        }
        $input = Input::except('_token','_method');

        if ($input['user_password'] == '') {

            unset($input['user_password']);

        } else {

	        $input['user_password'] = Crypt::encrypt($input['user_password']);
        }
	    unset($input['user_password_confirmation']);
	    if ($input['user_avatar'] == '') {

            unset($input['user_avatar']);
        }




        $re = User::where('user_id',$user_id)->update($input);
        if($re){
            return redirect('admin/users');
        }else{
            return back()->with('errors','会员更新失败，请稍后重试！');
        }
    }
}
