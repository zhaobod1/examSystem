<?php $__env->startSection('content'); ?>
    <!--内容区域-->
    <div class="container">
        <div class="row">
            <div class="col-xs-12">
                <h4>试卷编号:<?php echo e($paperInfo->paper_id); ?></h4>
                <h5>试卷总分: <span style="color:red"><?php echo e($paperInfo->total_score); ?></span></h5>

                <table class="table table-responsive table-striped">
                    <thead>
                    <tr>
                        <th>编号</th>
                        <th>标题</th>
                        <th>分值</th>
                        <th>成绩</th>
                    </tr>
                    </thead>
                    <?php foreach($questions as $question): ?>
                        <tr onclick="javascript:window.location.href='<?php echo e(url('getQuestion')); ?>' + '/' + '<?php echo e($question->question_id); ?>'">
                            <td><?php echo e($question->question_order); ?></td>
                            <td><?php echo e($question->question_title); ?></td>
                            <td><span style="color:red">
                                    <?php echo e($question->question_score); ?>

                                </span>
                            </td>
                            <td>
                                <span class="glyphicon glyphicon-<?php echo e($question->question_answer==$question->quest_answer ? 'ok' : 'remove'); ?>"></span>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </table>
                <nav>
                    <ul class="pagination">
                        <?php echo e($questions->links()); ?>

                    </ul>
                </nav>
            </div>
        </div>
    </div>
    <!--内容区域 end -->

<?php $__env->stopSection(); ?>





<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>