<?php

namespace App\Http\Controllers\Admin;

use App\Http\Model\PaperInfo;
use App\Http\Model\PaperQuestion;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class PaperController extends Controller
{
    //

	public function index($user_id)
	{

		$papers = PaperInfo::where('user_id', $user_id)
			->paginate(10);
		$sumPapers = PaperInfo::where('user_id', $user_id)->count();
		return view('admin.paper.index', compact('papers','sumPapers'));
	}

	public function questionList($paper_id)
	{

		if ($paper_id) {
			$paper_id = intval($paper_id);
			$questions = PaperQuestion::where('paper_id', $paper_id)
				->paginate(10);

			$sumQuestions = PaperQuestion::where('paper_id', $paper_id)->count();
			$total_score = PaperInfo::find($paper_id)->total_score;
		} else {
			//未知意外
			return redirect()->back();
		}

		return view('admin.paper.paper', compact('questions', 'sumQuestions', 'total_score'));
	}
}
