<?php

namespace App\Http\Controllers\Home;

use App\Http\Model\User;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Input;

class LoginController extends CommonController
{
    //

    public function login()
    {

        if ($input = Input::all()) {

        	if ($input['user_name']=='' || $input['user_password'] =='') {
		        return redirect()->back()->with('msg', '用户名或者密码不能为空!');

	        }
            $user = User::where('user_name', $input['user_name'])->get();
            $user = $user[0];
            if ($input['user_name'] != $user->user_name || $input['user_password'] != Crypt::decrypt($user->user_password)) {
                return redirect()->back()->with('msg', '用户名或者密码错误!');
            }

            session([
                'user' => $user
            ]);

            return redirect('index');

        }
        $pageTitle = '登录';
        return view('home.login', compact('pageTitle'));
    }

    public function quit()
    {
        session(['user' => null]);
        return redirect('login');
    }
}
