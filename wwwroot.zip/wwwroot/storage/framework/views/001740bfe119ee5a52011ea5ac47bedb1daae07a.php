<?php $__env->startSection('content'); ?>
    <!--内容区域-->
    <div class="container">
        <div class="row" style="padding-top: 50px;">
            <div class="col-xs-12">
                <div class="panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">请您绑定手机号</h3>
                    </div>
                    <div class="panel-body">

                        <?php if(count($errors)>0): ?>
                            <div class="mark">
                                <?php if(is_object($errors)): ?>
                                    <?php foreach($errors->all() as $error): ?>
                                        <p><?php echo e($error); ?></p>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <p><?php echo e($errors); ?></p>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <form action="" method="post">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <img width="100" src="<?php echo e($user->user_avatar); ?>" alt="" class="img-circle">
                            </div>
                            <div class="form-group hide">
                                <label class="">用户名</label>
                                <input type="text" disabled="disabled" name="user_name" class="form-control" placeholder=""
                                       value="<?php echo e($user->user_name); ?>">
                            </div>
                            <div class="form-group">
                                <label class="">学生姓名</label>
                                <input type="text" name="user_neckname" class="form-control" placeholder="填写正确的姓名" value="<?php echo e($user->user_neckname); ?>">
                            </div>
                            <div class="form-group">
                                <label class="">手机号码</label>
                                <input type="text" name="user_phone" class="form-control" placeholder=""
                                       value="<?php echo e($user->user_phone); ?>">
                            </div>
                            <div class="form-group">
                                <label class="">密码</label>
                                <input type="password" name="user_password" class="form-control" placeholder="输入新密码,留空代表不修改密码"
                                       value="">
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-block" style="background: #333;color:#fff;"
                                       value="确定">
                            </div>
                        </form>


                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--内容区域 end -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('style'); ?>
    <style>
        .login_wx {
            list-style: none;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>