@extends('layouts.admin')

@section('content')


    <script>
      $(function () {
        window.location.href="{{ $front_path }}";
      })
    </script>

@endsection