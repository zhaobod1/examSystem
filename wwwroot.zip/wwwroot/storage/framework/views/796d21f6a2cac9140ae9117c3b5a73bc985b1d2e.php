<?php $__env->startSection('content'); ?>


    <!--巨幕-->
    <div class="jumbotron">
        <div class="p10">
            <div class="mark">
                <?php if(session('msg')): ?>
                    <p style="color:red"><?php echo e(session('msg')); ?></p>
                <?php endif; ?>
                <?php if(is_object($errors)): ?>
                    <?php foreach($errors->all() as $error): ?>
                        <p><?php echo e($error); ?></p>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p><?php echo e($errors); ?></p>
                <?php endif; ?>
            </div>
            <p><?php echo e($userCheck); ?></p>
            <?php if($isChecked): ?>
                <?php if($bContinueExam == 1): ?>
                    <p>
                        上次考试用时： <span style="color:red;"><?php echo e($sumTime); ?></span>
                    </p>
                    <p>
                        <a href="/startexam" class="btn btn-primary">继续考试</a>
                    </p>
                <?php elseif($bContinueExam == 2): ?>
                    <p>
                        上次考试已经结束，您还没有交卷。
                    </p>
                    <p>
                        <a href="/handin" class="btn btn-primary">交卷</a>
                    </p>
                <?php else: ?>
                    <p>
                        <a href="/startexam" class="btn btn-primary">开始考试</a>
                    </p>
                <?php endif; ?>

            <?php endif; ?>
            <p><?php echo e(date('Y 年 m 月 d 日', time())); ?></p>
        </div>

    </div>
    <!--巨幕 end -->


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.home', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>