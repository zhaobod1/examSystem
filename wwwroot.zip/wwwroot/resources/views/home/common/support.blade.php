<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">在线客服 <span class="caret"></span></a>
    <ul class="dropdown-menu" role="menu">
        {{--<li><a href="http://bbs.huo15.com">有问必答</a></li>--}}
        <li>
            <a target="_blank" href="http://wpa.qq.com/msgrd?v=3&uin=3186355915&site=qq&menu=yes">
                <img border="0" src="http://wpa.qq.com/pa?p=2:3186355915:52" alt="有什么可以帮您？" title="有什么可以帮您？"/>
                联系管理员
            </a>
        </li>
        <li class="divider"></li>
        <li>
            <a href="http://www.huo15.com">火一五官网</a>
        </li>
    </ul>
</li>
