<?php

namespace App\Http\Controllers\Home;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Ixudra\Curl\Facades\Curl;

class WeChatController extends CommonController
{

	private $appid = 'wx5c9087febb6ff481';
	private $appsecret = 'ff0cde32b21b222b6cc134fedd27c37e';
	//获取用户的openid
	public function baseInfo()
	{

		//1.获取code
		$redirect_uri = urlencode('http://q.huo15.com/wechat/getCode');
		$scope = 'snsapi_base';
		$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $this->appid . '&redirect_uri=' . $redirect_uri. '&response_type=code&scope=' . $scope . '&state=STATE#wechat_redirect';
		header('location:' . $url);
	}

	public function getUserOpenId(Request $request)
	{
		//2.获取网页授权的access_token

		$code = $request->get('code');
		$url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' . $this->appid . '&secret=' . $this->appsecret . '&code=' . $code . '&grant_type=authorization_code';

		//3.拉取用户的openid
		$response = Curl::to($url)->get();
		/*
		 * { "access_token":"ACCESS_TOKEN",
			 "expires_in":7200,
			 "refresh_token":"REFRESH_TOKEN",
			 "openid":"OPENID",
			 "scope":"SCOPE" }
		*/
		dd($response);
		return $response['openid'];
	}

	public function getUserDetail()
	{

		//2-1.获取code
		$redirect_uri = urlencode('http://q.huo15.com/wechat/getUserInfo');
		$scope = 'snsapi_userinfo';
		$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $this->appid . '&redirect_uri=' . $redirect_uri. '&response_type=code&scope=' . $scope . '&state=STATE#wechat_redirect';
		header('location:' . $url);
	}

	public function getUserInfo(Request $request)
	{
		//2-2.获取网页授权的access_token

		dd($request->get('code'));
		$code = $_GET['code'];

		$url = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' . $this->appid . '&secret=' . $this->appsecret . '&code=' . $code . '&grant_type=authorization_code';

		$response = $this->call('GET', $url);
		$access_token = $response['access_token'];

		//2-3.拉取用户的详细信息
		$url = 'https://api.weixin.qq.com/sns/userinfo?access_token=' . $access_token . '&openid=' . $this->appid . '&lang=zh_CN';
		$response = $this->call('GET', $url);
		dd($response);
		/*
		 * {    "openid":" OPENID",
				 "nickname": NICKNAME,
				 "sex":"1",
				 "province":"PROVINCE"
				 "city":"CITY",
				 "country":"COUNTRY",
				 "headimgurl":    "http://wx.qlogo.cn/mmopen/g3MonUZtNHkdmzicIlibx6iaFqAc56vxLSUfpb6n5WKSYVY0ChQKkiaJSgQ1dZuTOgvLLrhJbERQQ4eMsv84eavHiaiceqxibJxCfHe/46",
				"privilege":[ "PRIVILEGE1" "PRIVILEGE2"     ],
				 "unionid": "o6_bmasdasdsad6_2sgVt7hMZOPfL"
				}
		 */

	}
}
