<?php

namespace App\Http\Controllers\Home;

use App\Http\Model\PaperInfo;
use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class CommonController extends Controller
{

	public function userCheck() {
		/*判断审核*/
		$sessionUser = session('user');
		return $sessionUser->user_check;
		/*判断审核 end*/
	}

	public function getSessionPaperId()
	{
		if (!session('paper_id')) {
			$res = PaperInfo::whereRaw('user_id=? and updated_at=?', [session('user')->user_id, 0])
				->select('paper_id')->first();
			if ($res) {
				session('paper_id', $res->paper_id);
				return $res->paper_id;
			} else {
				//如果没有等于0的更新试卷,选择最近的一个试卷
				$res = PaperInfo::whereRaw('user_id=?', [session('user')->user_id])
					->orderBy('updated_at', 'DESC')
					->select('paper_id')->first();
				return $res->paper_id;

			}
		} else {
			return session('paper_id');
		}
	}
}
